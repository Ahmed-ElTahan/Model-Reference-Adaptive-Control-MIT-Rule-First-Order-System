clc; close all; clear all;
global a;
global b;
global am;
global bm;
global gamma;


a = 2;
b = 0.5;
am = 3;
bm = 3;
gamma = 60;